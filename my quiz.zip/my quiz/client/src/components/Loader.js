import React from 'react'

function Loader() {
  return (
    <div className='loader-parent'>
      <div className='loader'></div>
    </div>
  )
}

export default Loader